<!DOCTYPE html>
<html>
<head>
    <title>Credenciales de acceso</title>
</head>
<body>
    <h1>¡Bienvenido a Utcj Sustentable!</h1>
    <p>Hola <?php echo e($nombre); ?>,</p>
    <p>Tu usuario y contraseña son:</p>
    <ul>
        <li><strong>Matrícula:</strong> <?php echo e($matricula); ?></li>
        <li><strong>Contraseña:</strong> <?php echo e($password); ?></li>
    </ul>
    <p>Por favor, ingresa en la App con estas credenciales para iniciar con las tareas asignadas.</p>
</body>
</html><?php /**PATH C:\laragon\www\utcj_sustentablekevin\resources\views/emails/credenciales.blade.php ENDPATH**/ ?>