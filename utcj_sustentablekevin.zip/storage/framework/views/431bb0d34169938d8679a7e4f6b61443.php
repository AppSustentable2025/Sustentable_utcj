
<?php $__env->startSection('content'); ?>

<main id="main" class="main">

    <div class="pagetitle">
        <div class="d-flex justify-content-between align-items-center">
            <h1>Creacion de cuentas y actividades</h1>

        </div>
        <nav>
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="index.html">Dashboard</a></li>
                <li class="breadcrumb-item">Crear actividades</li>
            </ol>
        </nav>
    </div><!-- End Page Title -->

    <!-- En la vista -->
    <?php if(session('success')): ?>
    <div class="alert alert-success alert-dismissible fade show" role="alert" style="font-weight: bold; font-size: 1.1em;">
        <i class="bi bi-check-circle me-1"></i>
        <?php echo e(session('success')); ?>

        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>
    <?php endif; ?>

    <?php if(session('error')): ?>
    <div class="alert alert-danger">
        <?php echo e(session('error')); ?>

    </div>
    <?php endif; ?>

    <section class="section">
        <div class="row">
            <div class="col-lg-6">

                <form action="<?php echo e(route('actividad.asignarTareas')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <div class="form-group">
                        <label for="actividad_id">Seleccionar Actividad</label>
                        <select name="actividad_id" id="actividad_id" class="form-control">
                            <?php $__currentLoopData = $actividades; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $actividad): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($actividad->id); ?>"><?php echo e($actividad->nombre); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>

                    <div class="form-group">
                        <label for="tareas">Seleccionar Tareas</label>
                        <select name="tareas[]" id="tareas" class="form-control" multiple>
                            <?php $__currentLoopData = $tareas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tarea): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($tarea->id); ?>"><?php echo e($tarea->nombre); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>

                    <button type="submit" class="btn btn-primary">Asignar Tareas</button>
                </form>


            </div>
    </section>
</main>
<!-- End #main -->
<?php $__env->stopSection(); ?>

<!-- Firebase Scripts -->
<script src="https://code.jquery.com/jquery-3.4.0.min.js"></script>
<script src="https://www.gstatic.com/firebasejs/5.10.1/firebase.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
<?php echo $__env->make('layouts.app2', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\utcj_sustentable\resources\views/asignar-tareas.blade.php ENDPATH**/ ?>