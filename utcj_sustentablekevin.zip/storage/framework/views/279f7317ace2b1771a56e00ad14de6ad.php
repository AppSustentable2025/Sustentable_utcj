

<?php $__env->startSection('content'); ?>

<main id="main" class="main">
    <div class="pagetitle">
        <h1>Lista de alumnos</h1>
        <nav>
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="<?php echo e(route('dashboard')); ?>">Dashboard</a></li>
                <li class="breadcrumb-item active">Lista de alumnos</li>
            </ol>
        </nav>
    </div><!-- End Page Title -->

    <section class="section">
        <div class="row">
            <div class="col-lg-12">
                <div class="card">
                    <div class="card-body">
                        <div class="d-flex justify-content-end mb-2">
                            <a href="<?php echo e(route('actividades.create')); ?>" class="btn btn-primary btn-sm px-4">Nuevo</a>
                        </div>

                        <!-- Tabla -->
                        <table class="table datatable">
                            <thead>
                                <tr>
                                    <th scope="col">#</th>
                                    <th scope="col">Matrícula</th>
                                    <th scope="col">Nombre</th>
                                    <th scope="col">Creado</th>
                                </tr>                            
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $alumnos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $alumno): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($alumno->id); ?></td>
                                        <td><?php echo e($alumno->matricula); ?></td>
                                        <td><?php echo e($alumno->nombre); ?></td>
                                        <td><?php echo e($alumno->created_at); ?></td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                        <!-- Fin Tabla -->
                    </div>
                </div>
            </div>
        </div>
    </section>

</main>

<?php $__env->stopSection(); ?>
<script src="https://cdn.datatables.net/1.13.4/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/1.13.4/js/dataTables.bootstrap5.min.js"></script>




<?php echo $__env->make('layouts.app2', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\utcj_sustentable\resources\views/lista-alumnos.blade.php ENDPATH**/ ?>