

<?php $__env->startSection('content'); ?>

<main id="main" class="main">

  
  <?php if(session('success')): ?>
  <p class="alert alert-success"><?php echo e(session('success')); ?></p>
  <?php endif; ?>

  <div class="pagetitle">
    <h1>Lista de Tareas</h1>
    <nav>
      <ol class="breadcrumb">
        <li class="breadcrumb-item"><a href="#">Inicio</a></li>
        <li class="breadcrumb-item active">Lista de Tareas</li>
      </ol>
    </nav>
  </div>

  <div class="container">
    <div class="card card-default">
      <div class="card-body">
        <h3>Crear Nueva Tarea</h3>
        <!-- Formulario para crear nueva tarea -->
        <!-- resources/views/tareas/index.blade.php -->
        <form action="<?php echo e(route('tareas.store')); ?>" method="POST">
          <?php echo csrf_field(); ?>
          <div class="form-group">
            <div class="col-sm-6">
              <input id="name" type="text" class="form-control" name="nombre" placeholder="Nombre de la tarea" required autofocus>
            </div>
          </div>
          <div class="form-group">
            <div class="col-sm-6">
              <textarea id="description" class="form-control" name="descripcion" placeholder="Descripción de la tarea"></textarea>
            </div>
          </div>
          <div class="form-group">
            <div class="col-sm-6">
              <input id="integrantes" type="text" class="form-control" name="integrantes" placeholder="Integrantes de la tarea" required>
            </div>
          </div>
          <button type="submit" class="btn btn-primary mb-2">Guardar</button>
        </form>

      </div>
    </div>

    <!-- resources/views/tareas/index.blade.php -->
    <table id="tareasTable" class="table datatable">
      <thead>
        <tr>
          <th>ID</th>
          <th>Nombre</th>
          <th>Descripción</th>
          <th>Integrantes</th> <!-- Nueva columna -->
          <th>Fecha de Creación</th>
          <th>Acciones</th>
        </tr>
      </thead>
      <tbody>
        <?php $__currentLoopData = $tareas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tarea): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
          <td><?php echo e($tarea->id); ?></td>
          <td><?php echo e($tarea->nombre); ?></td>
          <td><?php echo e($tarea->descripcion); ?></td>
          <td><?php echo e($tarea->integrantes); ?></td> <!-- Mostrar el campo 'integrantes' -->
          <td><?php echo e($tarea->created_at->format('d/m/Y H:i')); ?></td>
          <td class="text-center">
            <button class="btn btn-sm btn-primary" data-bs-toggle="modal" data-bs-target="#editModal<?php echo e($tarea->id); ?>">Editar</button>
            <form action="<?php echo e(route('tareas.destroy', $tarea->id)); ?>" method="POST" style="display:inline;">
              <?php echo csrf_field(); ?>
              <?php echo method_field('DELETE'); ?>
              <button type="submit" class="btn btn-sm btn-danger">Eliminar</button>
            </form>
          </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </tbody>
    </table>


    <!-- resources/views/tareas/index.blade.php -->
    <?php $__currentLoopData = $tareas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tarea): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <!-- Modal de edición -->
    <div class="modal fade" id="editModal<?php echo e($tarea->id); ?>" tabindex="-1" aria-labelledby="editModalLabel<?php echo e($tarea->id); ?>" aria-hidden="true">
      <div class="modal-dialog">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title" id="editModalLabel<?php echo e($tarea->id); ?>">Editar Tarea: <?php echo e($tarea->nombre); ?></h5>
            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
          </div>
          <div class="modal-body">
            <form action="<?php echo e(route('tareas.update', $tarea->id)); ?>" method="POST">
              <?php echo csrf_field(); ?>
              <?php echo method_field('PUT'); ?>
              <div class="form-group">
                <label for="name">Nombre de la tarea</label>
                <input id="name" type="text" class="form-control" name="nombre" value="<?php echo e($tarea->nombre); ?>" required autofocus>
              </div>
              <div class="form-group">
                <label for="description">Descripción</label>
                <textarea id="description" class="form-control" name="descripcion"><?php echo e($tarea->descripcion); ?></textarea>
              </div>
              <div class="form-group">
                <label for="integrantes">Integrantes</label>
                <input id="integrantes" type="text" class="form-control" name="integrantes" value="<?php echo e($tarea->integrantes); ?>">
              </div>
              <button type="submit" class="btn btn-primary mt-3">Actualizar</button>
            </form>
          </div>
        </div>
      </div>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

  </div>
</main>

<?php $__env->stopSection(); ?>

<!-- Incluir los scripts de jQuery y DataTables -->
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://cdn.datatables.net/1.11.5/js/jquery.dataTables.min.js"></script>
<?php echo $__env->make('layouts.app2', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\utcj_sustentablekevin\resources\views/lista-tareas.blade.php ENDPATH**/ ?>