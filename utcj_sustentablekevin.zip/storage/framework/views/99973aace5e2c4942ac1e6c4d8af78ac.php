<?php echo e($slot); ?>

<?php /**PATH C:\laragon\www\utcj_sustentable\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>