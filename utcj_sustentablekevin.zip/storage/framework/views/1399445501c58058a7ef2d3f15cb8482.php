
<?php $__env->startSection('content'); ?>

<main id="main" class="main">
  <div class="pagetitle">
    <h1>Lista de actividades</h1>
    <nav>
      <ol class="breadcrumb">
        <li class="breadcrumb-item"><a href="index.html">Dashboard</a></li>
        <li class="breadcrumb-item">Lista de actividades</li>
      </ol>
    </nav>
  </div><!-- End Page Title -->

  <section class="section">
    <div class="row">
      <div class="col-lg-12">
        <div class="card">
          <div class="card-body">
            <div class="d-flex justify-content-between">
              <h5 class="card-title">Actividades creadas</h5>
            </div>
            <div class="d-flex align-items-center mb-2">
              <!-- <a href="" class="btn btn-primary btn-sm px-4 me-2">+ Alumno</a> -->

              <!-- Botón para abrir el modal -->
              <a href="#" class="btn btn-primary btn-sm px-4 me-2" data-bs-toggle="modal" data-bs-target="#addAlumnoModal">+ Alumno</a>

              <!-- Modal -->
              <!-- Modal para agregar alumno -->
              <div class="modal fade" id="addAlumnoModal" tabindex="-1" aria-labelledby="addAlumnoModalLabel" aria-hidden="true">
                <div class="modal-dialog">
                  <div class="modal-content">
                    <div class="modal-header">
                      <h5 class="modal-title" id="addAlumnoModalLabel">Agregar Alumno</h5>
                      <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">

                      <!-- Mensaje de éxito -->
                      <?php if(session('success')): ?>
                      <div class="alert alert-success">
                        <?php echo e(session('success')); ?>

                      </div>
                      <?php endif; ?>

                      <!-- Mensaje de error -->
                      <?php if($errors->any()): ?>
                      <div class="alert alert-danger">
                        <ul>
                          <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <li><?php echo e($error); ?></li>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                      </div>
                      <?php endif; ?>

                      <form action="<?php echo e(route('registrar.alumno')); ?>" method="POST">
                        <?php echo csrf_field(); ?>

                        <!-- Select para Actividades -->
                        <div class="mb-3">
                          <label for="actividadSelect" class="form-label">Seleccionar Actividad</label>
                          <select id="actividadSelect" name="actividad_id" class="form-control" required>
                            <option value="">Seleccione una actividad</option>
                            <?php $__currentLoopData = $actividades; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $actividad): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($actividad->id); ?>"><?php echo e($actividad->Periodo); ?> - <?php echo e($actividad->Horario); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                          </select>
                        </div>

                        <!-- Select para Tareas -->
                        <div class="mb-3">
                          <label for="tareaSelect" class="form-label">Seleccionar Tarea</label>
                          <select id="tareaSelect" name="tarea_id" class="form-control" required>
                            <option value="">Seleccione una tarea</option>
                            <?php $__currentLoopData = $tareas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tarea): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($tarea->id); ?>"><?php echo e($tarea->nombre); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                          </select>
                        </div>

                        <!-- Campo para Matrícula -->
                        <div class="mb-3">
                          <label for="matriculaInput" class="form-label">Matrícula</label>
                          <input type="text" id="matriculaInput" name="matricula" class="form-control"
                            pattern="al[0-9]{8}@utcj\.edu\.mx" placeholder="Ej. al12345678@utcj.edu.mx" required>
                          <div class="invalid-feedback">Formato incorrecto: al+6 números+@utcj.edu.mx</div>
                        </div>

                        <!-- Campo para Nombre -->
                        <div class="mb-3">
                          <label for="nombreInput" class="form-label">Nombre</label>
                          <input type="text" id="nombreInput" name="nombre" class="form-control"
                            oninput="this.value = this.value.toUpperCase()" placeholder="Nombre del alumno" required>
                        </div>

                        <div class="modal-footer">
                          <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cerrar</button>
                          <button type="submit" class="btn btn-success">Guardar Alumno</button>
                        </div>
                      </form>
                    </div>
                  </div>
                </div>
              </div>


              <div class="flex-grow-1"></div>
              <a href="<?php echo e(route('actividades.create')); ?>" class="btn btn-primary btn-sm px-4">Nueva actividad</a>
            </div>

            <!-- Table with stripped rows -->
            <table id="actividadTable" class="table">
              <thead>
                <tr>
                  <th scope="col">Id</th>
                  <th scope="col">Periodo</th>
                  <th scope="col">Horario</th>
                </tr>
              </thead>
              <tbody>
                <?php $__currentLoopData = $actividades; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $actividad): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr data-id="<?php echo e($actividad->id); ?>" class="parent-row">
                  <td><a href="javascript:void(0)"><strong><?php echo e($actividad->id); ?></strong></a></td>
                  <td><?php echo e($actividad->Periodo); ?></td>
                  <td><?php echo e($actividad->Horario); ?></td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </tbody>
            </table>

            <!-- Hidden student tables -->
            <?php $__currentLoopData = $actividades; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $actividad): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div id="child-row-<?php echo e($actividad->id); ?>" class="child-row mt-2 mb-4" style="display:none;">
              <table class="table table-bordered">
                <thead>
                  <tr>
                    <th>ID Alumno</th>
                    <th>Nombre</th>
                  </tr>
                </thead>
                <tbody>
                  <?php $__currentLoopData = $actividad->alumnos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $alumno): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <tr>
                    <td>
                      <a href="javascript:void(0)" class="alumno-link" data-id="<?php echo e($alumno->id); ?>">
                        <strong><?php echo e($alumno->id); ?></strong>
                      </a>
                    </td>
                    <td><?php echo e($alumno->nombre); ?></td>
                  </tr>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
              </table>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <!-- End Hidden student tables -->

          </div>
        </div>
      </div>
    </div>
  </section>



</main>
<!-- End #main -->

<?php $__env->stopSection(); ?>

<!-- Scripts should be at the end -->
<link rel="stylesheet" href="https://cdn.datatables.net/1.13.4/css/jquery.dataTables.min.css">
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://cdn.datatables.net/1.13.4/js/jquery.dataTables.min.js"></script>

<script>
  $(document).ready(function() {
    // Initialize DataTable first
    $('#actividadTable').DataTable();

    // Manejar el clic en las filas de la tabla
    $('#actividadTable tbody').on('click', 'tr.parent-row', function() {
      var actividadId = $(this).data('id');
      var childRow = $('#child-row-' + actividadId);

      // Alternar la visibilidad de la fila secundaria
      if (childRow.is(':hidden')) {
        $('.child-row').hide(); // Hide all other open child rows
        childRow.show();
      } else {
        childRow.hide();
      }
    });

    // Event listener for student links
    $(document).on('click', '.alumno-link', function() {
      let alumnoId = $(this).data('id');
      window.location.href = "/tareas-alumno/" + alumnoId;
    });
  });
</script>
<?php echo $__env->make('layouts.app2', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\utcj_sustentablekevin\resources\views/lista-actividades.blade.php ENDPATH**/ ?>