<!DOCTYPE html>
<html>
<head>
    <title>Credenciales de Acceso</title>
</head>
<body>
    <h2>Hola, bienvenido a nuestra plataforma</h2>
    <p>Se ha generado tu cuenta con las siguientes credenciales:</p>
    <ul>
        <li><strong>Usuario:</strong> {{ $matricula }}</li>
        <li><strong>Contraseña:</strong> {{ $password }}</li>
    </ul>
    <p>Por favor, inicia sesión lo antes posible.</p>
</body>
</html>
